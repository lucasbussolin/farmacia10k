package Vendas;

import java.util.*;

public class Pagamento {

    public Pagamento() {
  
    }

    private double valorPago;
    private TipoPagamento tipo;
    private double desconto;

    public double gerarDesconto(TipoPagamento tipo) {
        return 0.0d;
    }

    public void getPagamento() {

    }

    public void setPagamento() {

    }

}