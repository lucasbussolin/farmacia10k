package Vendas;

import java.util.*;

public class Item {

    public Item() {
    
    }

}