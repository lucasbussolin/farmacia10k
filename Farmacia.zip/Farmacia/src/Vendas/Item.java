package Vendas;

public class Item {

    public Item() {
    
    }

}