package Vendas;

public class DAOVenda {

    public DAOVenda() {
   
    }

    public Venda registraVenda(Venda mel) {
    	return null;
    }

    public Relatorio geraRelatorio(Venda mel) {
    	return null;
    }

}
