package Vendas;

public class DAOVenda implements DAO.DAOVenda {

	@Override
	public void registraVenda(Venda mel) {
	}

	public Relatorio geraRelatorio(Venda mel){
		return null;
	}
	
}
