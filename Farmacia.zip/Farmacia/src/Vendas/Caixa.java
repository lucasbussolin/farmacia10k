package Vendas;

import java.util.ArrayList;

public class Caixa {

    public Caixa() {
   
    }

    private double dinheironoCaixa;
    private ArrayList<int> quantidadeCedulas;
    private ArrayList<int> quantidadeNotas;

    public Caixa getCaixa() {
        return null;
    }

    public Caixa setCaixa(Caixa cx) {
        return null;
    }

    public double calculaDinheiro(ArrayList cedulas, ArrayList notas) {
        return 0.0d;
    }

}
