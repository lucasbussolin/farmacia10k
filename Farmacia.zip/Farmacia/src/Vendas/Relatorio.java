package Vendas;

import java.util.*;

public class Relatorio {

    public Relatorio() {
   
    }

    public Date data;
    public String conteudo;

    public Relatorio getRelatorio() {
        return null;
    }

    public void setRelatorio(Relatorio rt) {

    }

}