package Vendas;

public class ComponenteVenda {

    public ComponenteVenda() {
    
    }

    public double valor;

    public double geraValor() {
        return 0.0d;
    }

    public void addComponente(ComponenteVenda cv) {
      
    }

    public ComponenteVenda removeComponente() {
        return null;
    }

    public ComponenteVenda getFilho() {
        return null;
    }

}