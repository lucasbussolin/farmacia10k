package Pessoas;

public class Gerente extends Usuario {

    public Gerente() {
    
    }

    public String senhaSuper;

}