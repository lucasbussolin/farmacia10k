package Pessoas;

public class DAOPessoa implements DAO.DAOPessoa {

	@Override
	public void validaUsuario(String senha) {
	}

	@Override
	public void cadastraUsuario(Usuario u) {
	}

	@Override
	public void cadastraCliente(Cliente c) {
	}

	@Override
	public Cliente buscaCliente(String cpf) {
		return null;
	}

}
