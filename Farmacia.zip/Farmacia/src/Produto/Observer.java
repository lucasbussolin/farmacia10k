package Produto;

public abstract class Observer{

    public Observer() {

    }

    public void atualizar() {

    }

}