package Produto;

import java.util.*;

import Interfaces.StrategyContabeis;

public class Medicamento extends Sujeito implements StrategyContabeis {

    public Medicamento() {
  
    }

    private String nome;
    private String fabricante;
    private Date validade;
    private double valorUnitario;
    private String descricao;
    private enum TipoUnidade;

    public Medicamento getMedicamento() {
        return null;
    }

    public Medicamento setMedicamento(Medicamento mdc) {
        return null;
    }

    public String organizaInformacoes() {
        return "";
    }

    public void addObserver(Observer o) {

    }

    public void removeObserver(Observer o) {

    }

    public void notificar() {

    }

}