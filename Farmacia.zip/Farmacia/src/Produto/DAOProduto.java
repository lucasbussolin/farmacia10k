package Produto;

public class DAOProduto implements DAO.DAOProduto {

	@Override
	public void cadastraMedicamento(Medicamento m) {
	}

	@Override
	public Medicamento buscaMedicamento(String nome) {
		return null;
	}

	@Override
	public void atualizaEstoque() {
	}

}
