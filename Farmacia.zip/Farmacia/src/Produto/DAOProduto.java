package Produto;


public class DAOProduto {

    public DAOProduto() {

    }

    public void cadastraMedicamento(Medicamento m) {

    }

    public Medicamento buscaMedicamento(String nome) {
    	return null;
    }

    public void atualizaEstoque() {

    }

}