package Visao;

public class FrmAbreCaixa {

	public FrmAbreCaixa() {
    
	}

}

