package Visao;

import java.util.*;

public class FrmAbreCaixa {

	public FrmAbreCaixa() {
    
	}

}

