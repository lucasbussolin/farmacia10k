package Visao;

public class FrmCadastraCliente {

    public FrmCadastraCliente() {
    
    }

}
