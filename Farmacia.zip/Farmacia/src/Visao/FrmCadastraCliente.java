package Visao;

import java.util.*;

public class FrmCadastraCliente {

    public FrmCadastraCliente() {
    
    }

}
