package Visao;

public class FrmRelatorio {

    public FrmRelatorio() {
    
    }

}