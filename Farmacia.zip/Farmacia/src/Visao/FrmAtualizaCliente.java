package Visao;

public class FrmAtualizaCliente {

    public FrmAtualizaCliente() {
    
    }

}