package Visao;

public class FrmFechaCaixa {

    public FrmFechaCaixa() {
    
    }

}