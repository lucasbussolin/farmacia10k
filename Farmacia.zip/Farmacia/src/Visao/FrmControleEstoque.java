package Visao;

public class FrmControleEstoque {

    public FrmControleEstoque() {
    
    }

}