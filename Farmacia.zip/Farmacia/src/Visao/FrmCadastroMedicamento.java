package Visao;

public class FrmCadastroMedicamento {

    public FrmCadastroMedicamento() {
   
    }

}