package Visao;

public class FrmAtualizaMedicamento {

    public FrmAtualizaMedicamento() {

    }

}