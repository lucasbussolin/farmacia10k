package DAO;

import Vendas.Venda;

public class DAOVenda {

    public DAOVenda() {

    }

    public void registraVenda(Venda mel) {

    }

}