package DAO;

import Vendas.Venda;

public interface DAOVenda {

	public void registraVenda(Venda mel);
	
}
