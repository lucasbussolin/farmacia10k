package Enum;

public enum TipoPagamento {
	cart�o,
	dinheiro,
	vale,
	cupom;
}
