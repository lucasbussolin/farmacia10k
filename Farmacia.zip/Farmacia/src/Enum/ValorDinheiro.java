package Enum;

public enum ValorDinheiro {
 	'0.05',
	'0.1',
	'0.25',
	'0.5',
	'1',
	'2',
	'5',
	'10',
	'20',
	'50',
	'100'
}