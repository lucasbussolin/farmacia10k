package Enum;

public enum TipoUnidade {
    litro,
    ampola,
    cartela,
    ml,
    comprimido
}