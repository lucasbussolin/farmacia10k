package Controle;

import Produto.Medicamento;
import Produto.Sujeito;
import Vendas.Pagamento;

public class CtrVenda extends Sujeito {

    public CtrVenda() {

    }

    public void realizaPagamento(Pagamento pgto) {

    }

    public boolean validaEstoque(Medicamento mdc) {
        return false;
    }

    public void emiteNf() {

    }

    public void controlaEstoque() {

    }

}