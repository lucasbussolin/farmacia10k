package Controle;

import Produto.Medicamento;

public class CtlMedicamento {

    public CtlMedicamento() {

    }

    public void salvarMedicamento(Medicamento mdc) {

    }

    public boolean checarValidade(Medicamento mdc) {
        return false;
    }

    public Medicamento buscarMedicamento(String nome) {
        return null;
    }

}