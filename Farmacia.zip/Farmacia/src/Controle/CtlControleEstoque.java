package Controle;

import Produto.Estoque;
import Produto.Medicamento;

public class CtlControleEstoque {

    public CtlControleEstoque() {

    }

    public boolean inserirNoEstoque(Estoque est) {
        return false;
    }

    public boolean removerDoEstoque(Estoque est) {
        return false;
    }

    public Medicamento consultarEstoque(Estoque est) {
        return null;
    }

}