package Controle;

import Interfaces.AbrirCaixa;
import Pessoas.Usuario;
import Vendas.Caixa;

public class CtlCaixa implements AbrirCaixa {

    public CtlCaixa() {

    }

    public void adicionarMoedas(Caixa cx) {

    }

    public void abrirCaixa(Caixa cx) {

    }

    public void contabilizarVendas(Caixa cx) {

    }

    public void fecharCaixa(Caixa cx) {

    }

    public boolean verificarSenha(Usuario usr) {
        return false;
    }


    public void adicionarCedulas(Caixa cx) {

    }

	public void abrirCaixa(AbrirCaixa cx) {
		
	}

}