package Controle;

import Vendas.Relatorio;

public class CtrRelatorio {

    public CtrRelatorio() {

    }

    public Relatorio geraRelatorio() {
        return null;
    }

}