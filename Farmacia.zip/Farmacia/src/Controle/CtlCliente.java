package Controle;

import Pessoas.Cliente;

public class CtlCliente {

    public CtlCliente() {

    }

    public boolean validaIdade(Cliente clt) {
        return false;
    }

    public boolean gravaCliente(Cliente clt) {
        return false;
    }

    public Cliente procurarCliente(Cliente clt) {
        return null;
    }

    public boolean validaCpf(Cliente clt) {
        return false;
    }

}