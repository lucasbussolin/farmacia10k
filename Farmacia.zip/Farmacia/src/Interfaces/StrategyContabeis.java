package Interfaces;

public interface StrategyContabeis {

    public String organizaInformacoes();

}